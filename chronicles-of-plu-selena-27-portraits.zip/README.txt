THE CHRONICLES OF PLU AND SELENA — BESTIARY PORTRAITS

27 separate WebP portrait assets cropped from the newly approved 22-panel lineup.

Male + female portraits: elves, druids, vampires, minotaurs, goblins.
Female portraits: dark-elves, dwarves, dragons, giants, ogres, cyclopes, succubi, witches-wiccans, fairies, werewolves, harpies, nymphs, leprechauns, humans, hybrids, monsters, dark-slimes.

Suggested destination in the website repository: assets/creatures/
Keep filenames unchanged. The images are visual interpretations; the manuscript remains authoritative for canon.
