CHRONICLES OF PLU — DEDICATED GAME CONCEPT VISUALS

These files are intended for the Game Concept page, separate from the main book website artwork.

UPLOAD STEPS (GitHub repository jazmin072/Test):
1. Open https://github.com/jazmin072/Test/tree/main/assets
2. Upload all 12 .webp images from this ZIP's assets/game-concept/ folder to assets/game-concept/ in the repository. Create the folder if it does not exist.
3. Keep the exact filenames. The page game-concept.html already refers to these filenames.
4. Commit the uploads to the main branch. Vercel should deploy automatically; verify https://chronicles-of-plu-and.vercel.app/game-concept.html afterwards.

This archive includes ten supplied concept mockups and two revised visual studies.
The artwork is visual direction, not real gameplay footage or a playable game.
Some exploratory mockups show a customizable adventurer identified as Plu. This is not a change to canon.
Do not replace the book-site character and gallery imagery; this folder is game-only.
